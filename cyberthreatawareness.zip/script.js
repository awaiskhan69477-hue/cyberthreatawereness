const container = document.querySelector(".container");

let score = 0;
let currentQuestion = 0;
let participantData = {};

// Stores every answer given by the participant
let answerHistory = [];

const questions = [

    {
        title: "Scenario 1: Suspicious Bank Email",
        type: "Email Safety Check",

        intro: `
            <div class="scenario-intro">
                <p><strong>What are you looking at?</strong></p>
                <p>Below is an email claiming to be from a bank.</p>

                <p><strong>What should you do?</strong></p>
                <p>Read the email carefully and decide whether it is legitimate, suspicious, or phishing.</p>
            </div>
        `,

        scenario: `
            <div class="email-box">
                <p><strong>From:</strong> security-bank@gmail.com</p>
                <p><strong>Subject:</strong> Urgent! Your Account Will Be Suspended</p>

                <br>

                <p>Dear Customer,</p>

                <p>
                    We detected unusual activity on your bank account.
                    Click the link below within 24 hours to verify your
                    account, otherwise your account will be suspended.
                </p>

                <br>

                <p><strong>Verify Account Now</strong></p>
            </div>
        `,

        question: "What do you think about this email?",

        options: [
            "Legitimate",
            "Suspicious",
            "Phishing"
        ],

        correct: 2,

        explanation: `
            This is a phishing email. The warning signs include the unusual sender address,
            urgent language, and pressure to click a link.
        `
    },

    {
        title: "Scenario 2: Delivery SMS",
        type: "SMS Safety Check",

        intro: `
            <div class="scenario-intro">
                <p><strong>What are you looking at?</strong></p>
                <p>Below is a text message claiming that a parcel delivery has failed.</p>

                <p><strong>What should you do?</strong></p>
                <p>Read the message and choose the safest action.</p>
            </div>
        `,

        scenario: `
            <div class="email-box">
                <p><strong>SMS Message:</strong></p>

                <p>
                    Your parcel delivery failed.
                    Pay ₹25 immediately to reschedule your delivery.
                </p>

                <p><strong>delivery-update.example/track</strong></p>
            </div>
        `,

        question: "What is the safest action?",

        options: [
            "Click the link and pay immediately",
            "Reply with personal information",
            "Verify through the official website or app"
        ],

        correct: 2,

        explanation: `
            Unexpected messages asking for payment or directing you to an unfamiliar link
            should be treated carefully. Verify through the official delivery website or app.
        `
    },

    {
        title: "Scenario 3: Suspicious Website",
        type: "Website Safety Check",

        intro: `
            <div class="scenario-intro">
                <p><strong>What are you looking at?</strong></p>
                <p>Below are two website addresses that appear to be related to the same bank.</p>

                <p><strong>What should you do?</strong></p>
                <p>Look carefully at the domain names and identify which one looks more suspicious.</p>
            </div>
        `,

        scenario: `
            <div class="email-box">
                <p><strong>Website A</strong></p>
                <p>https://www.examplebank.com/login</p>

                <br>

                <p><strong>Website B</strong></p>
                <p>https://examplebank-secure-login.com</p>
            </div>
        `,

        question: "Which website should be treated as more suspicious?",

        options: [
            "Website A",
            "Website B",
            "Both are definitely safe"
        ],

        correct: 1,

        explanation: `
            Website B should be treated with caution. Attackers often create domains that
            include a trusted company's name but are not the company's real website.
        `
    },

    {
        title: "Scenario 4: Bank Phone Call",
        type: "Phone Scam Check",

        intro: `
            <div class="scenario-intro">
                <p><strong>What are you looking at?</strong></p>
                <p>Imagine you receive a phone call from someone claiming to work for your bank.</p>

                <p><strong>What should you do?</strong></p>
                <p>Read the situation and choose the safest response.</p>
            </div>
        `,

        scenario: `
            <div class="email-box">
                <p>The caller says:</p>

                <p>
                    <strong>
                    "We detected suspicious activity on your account.
                    Please tell me the OTP you just received so we can secure your account."
                    </strong>
                </p>
            </div>
        `,

        question: "What should you do?",

        options: [
            "Share the OTP",
            "Disconnect and contact the bank using an official number",
            "Share only part of the OTP"
        ],

        correct: 1,

        explanation: `
            Never share an OTP with an unknown caller. If you are concerned about your account,
            contact the bank directly using its official app, website, or phone number.
        `
    },

    {
        title: "Scenario 5: UPI Payment Request",
        type: "Payment Fraud Check",

        intro: `
            <div class="scenario-intro">
                <p><strong>What are you looking at?</strong></p>
                <p>This situation involves someone claiming they want to send you money through UPI.</p>

                <p><strong>What should you do?</strong></p>
                <p>Read carefully and choose the safest response before entering your UPI PIN.</p>
            </div>
        `,

        scenario: `
            <div class="email-box">
                <p>
                    Someone says they want to send you ₹2,000.
                </p>

                <p>
                    They send you a UPI Collect Request and tell you:
                </p>

                <p><strong>"Enter your UPI PIN to receive the money."</strong></p>
            </div>
        `,

        question: "What is the safest response?",

        options: [
            "Enter the UPI PIN immediately",
            "Check what transaction you are approving before entering your PIN",
            "Share the UPI PIN with the sender"
        ],

        correct: 1,

        explanation: `
            Never enter your UPI PIN without understanding what transaction you are approving.
            Carefully check payment or collect requests before authorizing them.
        `
    },

    {
        title: "Scenario 6: Prize Message",
        type: "Online Scam Check",

        intro: `
            <div class="scenario-intro">
                <p><strong>What are you looking at?</strong></p>
                <p>Below is a message claiming that you have won an expensive prize.</p>

                <p><strong>What should you do?</strong></p>
                <p>Identify the main warning sign in the message.</p>
            </div>
        `,

        scenario: `
            <div class="email-box">
                <p><strong>Congratulations!</strong></p>

                <p>You have won a brand new smartphone.</p>

                <p>
                    To claim your prize, pay a processing fee of ₹499
                    within the next 30 minutes.
                </p>
            </div>
        `,

        question: "Which is the biggest warning sign?",

        options: [
            "An unexpected prize combined with a payment request",
            "The message says congratulations",
            "The smartphone is expensive"
        ],

        correct: 0,

        explanation: `
            Unexpected prizes that require advance payment are a common scam pattern.
            Do not send money simply to claim an unexpected reward.
        `
    },

    {
        title: "Scenario 7: Job Offer",
        type: "Job Scam Check",

        intro: `
            <div class="scenario-intro">
                <p><strong>What are you looking at?</strong></p>
                <p>Below is a job offer received without an interview.</p>

                <p><strong>What should you do?</strong></p>
                <p>Choose the safest action before responding or sending money.</p>
            </div>
        `,

        scenario: `
            <div class="email-box">
                <p><strong>Congratulations!</strong></p>

                <p>
                    You have been selected for a high-paying job without an interview.
                </p>

                <p>
                    Please pay ₹1,500 for registration and training
                    to confirm your position.
                </p>
            </div>
        `,

        question: "What should you do?",

        options: [
            "Pay immediately",
            "Verify the company and job offer through official sources",
            "Send bank details for registration"
        ],

        correct: 1,

        explanation: `
            Be careful when an unexpected job offer asks for money.
            Verify the organization and job offer through official sources before taking action.
        `
    },

    {
        title: "Scenario 8: Email Attachment",
        type: "Attachment Safety Check",

        intro: `
            <div class="scenario-intro">
                <p><strong>What are you looking at?</strong></p>
                <p>Below is an unexpected email with an attached file.</p>

                <p><strong>What should you do?</strong></p>
                <p>Look at the file type and identify the main security concern.</p>
            </div>
        `,

        scenario: `
            <div class="email-box">
                <p><strong>Subject:</strong> Salary Revision Details - Urgent</p>

                <p>You were not expecting this email.</p>

                <p>
                    Attachment:
                    <strong>Salary_Details.exe</strong>
                </p>
            </div>
        `,

        question: "What is the main security concern?",

        options: [
            "The attachment is an executable file",
            "The word Salary is suspicious",
            "The email has a subject line"
        ],

        correct: 0,

        explanation: `
            An unexpected executable file can be dangerous. Do not open unknown attachments
            until you have verified that the sender and file are legitimate.
        `
    },

    {
        title: "Scenario 9: Password Reset",
        type: "Account Security Check",

        intro: `
            <div class="scenario-intro">
                <p><strong>What are you looking at?</strong></p>
                <p>Below is a message claiming that your account has been compromised.</p>

                <p><strong>What should you do?</strong></p>
                <p>Choose the first thing you should check before clicking the link.</p>
            </div>
        `,

        scenario: `
            <div class="email-box">
                <p>Your account has been compromised.</p>

                <p>
                    Reset your password immediately using the link below:
                </p>

                <p>
                    <strong>
                    https://account-security-reset.example/login
                    </strong>
                </p>
            </div>
        `,

        question: "What should you check first?",

        options: [
            "Click the link immediately",
            "Check whether the sender and website domain are legitimate",
            "Send your password to the sender"
        ],

        correct: 1,

        explanation: `
            Account-security messages can sometimes be used to steal login credentials.
            Check the sender and website carefully, or visit the official service directly.
        `
    },

    {
        title: "Scenario 10: Final Challenge",
        type: "Mixed Threat Detection",

        intro: `
            <div class="scenario-intro">
                <p><strong>What are you looking at?</strong></p>
                <p>This final scenario combines several warning signs commonly found in suspicious messages.</p>

                <p><strong>What should you do?</strong></p>
                <p>Read carefully and choose the answer that best describes the message.</p>
            </div>
        `,

        scenario: `
            <div class="email-box">
                <p><strong>From:</strong> support@pay-support-help.example</p>

                <p>
                    <strong>Subject:</strong>
                    Action Required: Payment Account Verification
                </p>

                <br>

                <p>
                    Your account will be permanently restricted today
                    unless you verify your information immediately.
                </p>

                <p><strong>Verify Account</strong></p>
            </div>
        `,

        question: "Which answer best describes this message?",

        options: [
            "Safe because it looks professional",
            "Suspicious because of urgency and the unusual sender domain",
            "Safe because it asks for verification"
        ],

        correct: 1,

        explanation: `
            This message contains multiple warning signs, including pressure to act immediately
            and an unusual sender domain. Always verify important account messages independently.
        `
    }

];


// START BUTTON

const startBtn = document.getElementById("startBtn");

startBtn.addEventListener("click", function () {
    showLearningSection();
});
// LEARNING SECTION

function showLearningSection() {

    container.innerHTML = `

        <div class="card">

            <h1>Learn Before You Test</h1>

            <p class="subtitle">
                Before starting the assessment, learn how to identify
                common warning signs of phishing, scams, and online fraud.
            </p>

            <div class="scenario-intro">

                <p><strong>1. Check the sender</strong></p>

                <p>
                    Be careful with unexpected messages from unusual,
                    misspelled, or unfamiliar email addresses and phone numbers.
                </p>

            </div>


            <div class="scenario-intro">

                <p><strong>2. Look at the link</strong></p>

                <p>
                    Check the website address carefully. Attackers may use
                    misleading domains that look similar to trusted websites.
                </p>

            </div>


            <div class="scenario-intro">

                <p><strong>3. Watch for urgency</strong></p>

                <p>
                    Messages that threaten account suspension, demand
                    immediate payment, or create panic should be treated carefully.
                </p>

            </div>


            <div class="scenario-intro">

                <p><strong>4. Never share sensitive information</strong></p>

                <p>
                    Never share passwords, OTPs, PINs, or other sensitive
                    information because someone asks for them through an
                    unexpected call or message.
                </p>

            </div>


            <div class="scenario-intro">

                <p><strong>5. Verify independently</strong></p>

                <p>
                    Instead of using a link or phone number provided in a
                    suspicious message, contact the organization through
                    its official website, application, or known contact details.
                </p>

            </div>


            <div class="privacy-note">

                <strong>Remember:</strong>

                <p>
                    Stop, check, and verify before clicking a link,
                    opening an attachment, sharing information, or making a payment.
                </p>

            </div>


            <button id="continueAssessmentBtn" class="primary-btn">
                Continue to Assessment
            </button>

        </div>

    `;


    document
        .getElementById("continueAssessmentBtn")
        .addEventListener("click", function () {

            showParticipantForm();

        });

}

// PARTICIPANT INFORMATION FORM

function showParticipantForm() {

    container.innerHTML = `

        <h1>Participant Information</h1>

        <p class="subtitle">
            Please complete the information below before starting the assessment.
        </p>

        <div class="card">

            <form id="preAssessmentForm">

                <div class="form-group">
                    <label>1. Full Name</label>

                    <input
                        type="text"
                        id="name"
                        placeholder="Enter your name"
                        required
                    >
                </div>

                <div class="form-group">
                    <label>2. Select Your Age Group</label>

                    <select id="age" required>
                        <option value="">Select your age group</option>
                        <option>Below 18</option>
                        <option>18–25</option>
                        <option>26–35</option>
                        <option>36–50</option>
                        <option>Above 50</option>
                    </select>
                </div>


                <div class="form-group">
                    <label>3. What is your favourite area of interest?</label>

                    <select id="interest" required>
                        <option value="">Select an option</option>
                        <option>Technology</option>
                        <option>Sports</option>
                        <option>Science</option>
                        <option>Arts & Entertainment</option>
                        <option>Gaming</option>
                        <option>Other</option>
                    </select>
                </div>

                <div class="form-group">
                    <label>4. Are you interested in Cybersecurity?</label>

                    <select id="cybersecurity" required>
                        <option value="">Select an option</option>
                        <option>Yes, very interested</option>
                        <option>Yes, somewhat interested</option>
                        <option>Not sure</option>
                        <option>No</option>
                    </select>
                </div>

                <div class="form-group">
                    <label>
                        5. Have you ever received a suspicious email,
                        SMS, phone call, or online message?
                    </label>

                    <select id="experience" required>
                        <option value="">Select an option</option>
                        <option>Yes</option>
                        <option>No</option>
                        <option>Not Sure</option>
                    </select>
                </div>

                <button type="submit">
                    Begin Assessment
                </button>

            </form>

        </div>
    `;

    document
        .getElementById("preAssessmentForm")
        .addEventListener("submit", function (event) {

            event.preventDefault();

            participantData = {
    name: document.getElementById("name").value,
    age: document.getElementById("age").value,
    interest: document.getElementById("interest").value,
    cybersecurity: document.getElementById("cybersecurity").value,
    experience: document.getElementById("experience").value
};

// Reset assessment data
score = 0;
currentQuestion = 0;
answerHistory = [];

showQuestion();
        });
}


// SHOW QUESTION

function showQuestion() {

    const question = questions[currentQuestion];

    container.innerHTML = `

        <h1>${question.title}</h1>

        <p class="subtitle">
            Question ${currentQuestion + 1} of ${questions.length}
        </p>

        <div class="card">

            <h2>${question.type}</h2>

            ${question.intro}

            ${question.scenario}

            <h3>${question.question}</h3>

            <div class="options">

                ${question.options.map((option, index) => `

                    <button
                        class="answer-btn"
                        data-index="${index}">

                        ${option}

                    </button>

                `).join("")}

            </div>

            <div id="feedback"></div>

            <button
                id="nextBtn"
                style="display: none;">

                Next Scenario

            </button>

        </div>
    `;

    const answerButtons =
        document.querySelectorAll(".answer-btn");

    answerButtons.forEach(function (button) {

        button.addEventListener("click", function () {

            checkAnswer(
                Number(button.dataset.index)
            );

        });

    });
}


// CHECK ANSWER

function checkAnswer(selectedAnswer) {

    const question = questions[currentQuestion];

    const buttons = document.querySelectorAll(".answer-btn");

    buttons.forEach(function (button) {
        button.disabled = true;
    });

    const feedback = document.getElementById("feedback");

    const isCorrect = selectedAnswer === question.correct;


    // Save the participant's answer
    answerHistory.push({
        scenarioNumber: currentQuestion + 1,
        title: question.title,
        type: question.type,
        selectedAnswer: selectedAnswer,
        selectedText: question.options[selectedAnswer],
        correctAnswer: question.correct,
        correctText: question.options[question.correct],
        isCorrect: isCorrect,
        explanation: question.explanation
    });


    if (isCorrect) {

        score++;

        feedback.innerHTML = `
            <div class="feedback correct">
                <h3>✓ Correct!</h3>

                <p>
                    ${question.explanation}
                </p>
            </div>
        `;

    } else {

        feedback.innerHTML = `
            <div class="feedback wrong">

                <h3>✗ Incorrect</h3>

                <p>
                    <strong>Your answer:</strong>
                    ${question.options[selectedAnswer]}
                </p>

                <p>
                    <strong>Correct answer:</strong>
                    ${question.options[question.correct]}
                </p>

                <p>
                    ${question.explanation}
                </p>

            </div>
        `;
    }


    const nextBtn = document.getElementById("nextBtn");

    nextBtn.style.display = "inline-block";


    if (currentQuestion === questions.length - 1) {
        nextBtn.textContent = "View Results";
    }


    nextBtn.addEventListener("click", function () {

        currentQuestion++;

        if (currentQuestion < questions.length) {

            showQuestion();

        } else {

            showResults();

        }

    });
}
// FINAL RESULTS

// FINAL RESULTS DASHBOARD

function showResults() {

    const totalQuestions = questions.length;
    const correctAnswers = score;
    const incorrectAnswers = totalQuestions - correctAnswers;

    const percentage =
        Math.round((score / totalQuestions) * 100);


    // --------------------------------
    // AWARENESS LEVEL
    // --------------------------------

    let awarenessLevel = "";
    let recommendation = "";

    if (percentage >= 80) {

        awarenessLevel = "HIGH AWARENESS";

        recommendation =
            "You demonstrated strong awareness of common phishing, scam, and fraud warning signs. Continue verifying senders, links, payment requests, and unexpected messages.";

    } else if (percentage >= 50) {

        awarenessLevel = "MODERATE AWARENESS";

        recommendation =
            "You identified several threats correctly, but some areas need improvement. Pay closer attention to suspicious links, urgency, payment requests, and social engineering.";

    } else {

        awarenessLevel = "NEEDS MORE AWARENESS";

        recommendation =
            "You should strengthen your understanding of phishing, suspicious links, social engineering, and online payment fraud. Always stop and verify before taking action.";
    }


    // --------------------------------
    // TOPIC PERFORMANCE
    // --------------------------------

    const topicStats = {};

    answerHistory.forEach(function (result) {

        if (!topicStats[result.type]) {

            topicStats[result.type] = {
                total: 0,
                correct: 0
            };

        }

        topicStats[result.type].total++;

        if (result.isCorrect) {
            topicStats[result.type].correct++;
        }

    });


    // --------------------------------
    // CREATE TOPIC PERFORMANCE HTML
    // --------------------------------

    let topicPerformanceHTML = "";

    

           Object.keys(topicStats).forEach(function (topicName) {

    const topicData = topicStats[topicName];

    const topicPercentage =
        Math.round((topicData.correct / topicData.total) * 100);

    topicPerformanceHTML += `

        <div class="topic-result">

            <div class="topic-result-header">

                <span>${topicName}</span>

                <strong>${topicPercentage}%</strong>

            </div>

            <div class="topic-bar">

                <div
                    class="topic-bar-fill"
                    style="width: ${topicPercentage}%;">
                </div>

            </div>

            <small>
                ${topicData.correct} of ${topicData.total} correct
            </small>

        </div>

    `;

});

    // --------------------------------
    // STRENGTHS
    // --------------------------------

    let strengths = [];

    answerHistory.forEach(function (result) {

        if (result.isCorrect) {
            strengths.push(result.type);
        }

    });

    strengths = [...new Set(strengths)];


    let strengthsHTML = "";

    if (strengths.length > 0) {

        strengths.forEach(function (strength) {

            strengthsHTML += `
                <li>✓ ${strength}</li>
            `;

        });

    } else {

        strengthsHTML = `
            <li>Continue practicing basic threat recognition.</li>
        `;

    }


    // --------------------------------
    // MISTAKES
    // --------------------------------

    const mistakes =
        answerHistory.filter(function (result) {
            return !result.isCorrect;
        });


    let mistakesHTML = "";

    if (mistakes.length === 0) {

        mistakesHTML = `
            <div class="no-mistakes">
                <h3>Excellent!</h3>
                <p>
                    You answered every scenario correctly.
                    Keep applying the same verification habits in real life.
                </p>
            </div>
        `;

    } else {

        mistakes.forEach(function (mistake) {

            mistakesHTML += `

                <div class="mistake-item">

                    <h3>
                        Scenario ${mistake.scenarioNumber}:
                        ${mistake.title}
                    </h3>

                    <p>
                        <strong>Your answer:</strong>
                        ${mistake.selectedText}
                    </p>

                    <p>
                        <strong>Correct answer:</strong>
                        ${mistake.correctText}
                    </p>

                    <div class="mistake-explanation">

                        <strong>Why?</strong>

                        <p>
                            ${mistake.explanation}
                        </p>

                    </div>

                </div>

            `;

        });

    }


    // --------------------------------
    // AREAS TO IMPROVE
    // --------------------------------

    let improvementTopics = [];

    Object.keys(topicStats).forEach(function (topicName) {

        const topicData = topicStats[topicName];

        const topicPercentage =
            Math.round(
                (topicData.correct / topicData.total) * 100
            );

        if (topicPercentage < 70) {

            improvementTopics.push(topicName);

        }

    });


    let improvementHTML = "";

    if (improvementTopics.length === 0) {

        improvementHTML = `
            <p>
                No major learning gaps were identified.
                Continue practicing regularly.
            </p>
        `;

    } else {

        improvementTopics.forEach(function (topic) {

            improvementHTML += `
                <div class="improvement-item">
                    ⚠️ ${topic}
                </div>
            `;

        });

    }


    // --------------------------------
    // FINAL DASHBOARD
    // --------------------------------

    container.innerHTML = `

        <div class="dashboard-header">

            <p class="project-tag">
                CYBERSECURITY AWARENESS REPORT
            </p>

            <h1>Assessment Results</h1>

            <p class="subtitle">
                Personalized analysis of your phishing, scam
                and fraud awareness.
            </p>

        </div>


        <!-- PARTICIPANT -->

        <div class="card participant-summary">

            <h2>Participant Summary</h2>

            <p>
                <strong>Name:</strong>
                ${participantData.name}
            </p>

            <p>
                <strong>Assessment:</strong>
                Phishing, Scam & Fraud Awareness
            </p>

            <p>
                <strong>Total Scenarios:</strong>
                ${totalQuestions}
            </p>

        </div>


        <!-- SCORE -->

        <div class="card score-dashboard">

            <div class="main-score">

                <div class="score-circle">

                    <span>${percentage}%</span>

                </div>

                <h2>${awarenessLevel}</h2>

                <p>
                    You answered
                    <strong>${correctAnswers}</strong>
                    out of
                    <strong>${totalQuestions}</strong>
                    scenarios correctly.
                </p>

            </div>


            <div class="score-stats">

                <div class="score-stat">

                    <span>Correct</span>

                    <strong>${correctAnswers}</strong>

                </div>

                <div class="score-stat">

                    <span>Incorrect</span>

                    <strong>${incorrectAnswers}</strong>

                </div>

                <div class="score-stat">

                    <span>Percentage</span>

                    <strong>${percentage}%</strong>

                </div>

            </div>

        </div>


        <!-- TOPIC PERFORMANCE -->

        <div class="card">

            <h2>Performance by Topic</h2>

            <p>
                This section shows how you performed across
                different types of cybersecurity threats.
            </p>

            <div class="topic-performance">

                ${topicPerformanceHTML}

            </div>

        </div>


        <!-- STRENGTHS -->

        <div class="card">

            <h2>Your Strengths</h2>

            <ul class="strength-list">

                ${strengthsHTML}

            </ul>

        </div>


        <!-- MISTAKES -->

        <div class="card">

            <h2>Review Your Mistakes</h2>

            <p>
                Reviewing mistakes helps you understand
                what went wrong instead of only seeing a score.
            </p>

            <div class="mistake-list">

                ${mistakesHTML}

            </div>

        </div>


        <!-- AREAS TO IMPROVE -->

        <div class="card">

            <h2>Areas to Improve</h2>

            <p>
                Based on your answers, these are the topics
                that may require additional practice.
            </p>

            <div class="improvement-list">

                ${improvementHTML}

            </div>

        </div>


        <!-- RECOMMENDATION -->

        <div class="card recommendation">

            <h2>Personal Recommendation</h2>

            <p>
                ${recommendation}
            </p>

        </div>


        <!-- SAFETY CHECKLIST -->

        <div class="card safety-card">

            <h2>Cyber Safety Checklist</h2>

            <div class="warning-list">

                <p>🛑 <strong>STOP</strong> — Do not react immediately.</p>

                <p>🔎 <strong>CHECK</strong> — Examine the sender, link, request or attachment.</p>

                <p>✅ <strong>VERIFY</strong> — Use an official website, app or known contact method.</p>

                <p>🚨 <strong>REPORT</strong> — Report suspicious activity when appropriate.</p>

            </div>

        </div>


        <!-- PRIVACY -->

        <div class="privacy-note">

            <strong>Privacy Notice:</strong>

            This assessment does not store your information
            in a database or send it to a server.

        </div>


        <div class="start-card">

            <button onclick="location.reload()" class="primary-btn">

                Take Assessment Again

            </button>

        </div>

    `;

}